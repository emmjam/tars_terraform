//console.log('Loading event');

var aws = require('aws-sdk');
var ddb = new aws.DynamoDB({params: {TableName: 'SESNotifications'}});

exports.handler = function(event, context) {
  //console.log('Received event:', JSON.stringify(event, null, 2));
  var SnsPublishTime = event.Records[0].Sns.Timestamp;
  var SnsTopicArn = event.Records[0].Sns.TopicArn;
  var SESMessage = event.Records[0].Sns.Message;
  SESMessage = JSON.parse(SESMessage);
  var SESMessageType = SESMessage.notificationType;
  var SESMessageId = SESMessage.mail.messageId;
  var SESDestinationAddress = SESMessage.mail.destination.toString();
  var LambdaReceiveTime = new Date().toString();
  var expiry_timestamp_epoch_secs = Math.floor(Date.now() / 1000) + (process.env.record_expiry_days * 86400); 
  var ExpiryTimestamp = expiry_timestamp_epoch_secs.toString();
  
  if (SESMessageType == 'Bounce') {
    var SESbounceSummary = JSON.stringify(SESMessage.bounce.bouncedRecipients);
    var SESbounceType = SESMessage.bounce.bounceType;
    var SESbounceSubType = SESMessage.bounce.bounceSubType;
    var SESbouncereportingMTA = SESMessage.bounce.reportingMTA;
    if (SESbouncereportingMTA == null) SESbouncereportingMTA = "UNKNOWN";
    var itembounceParams = {Item: {SESMessageId: {S: SESMessageId}, SnsPublishTime: {S: SnsPublishTime},
                     ExpiryTimestamp: {N: ExpiryTimestamp}, SESreportingMTA: {S: SESbouncereportingMTA},
                     SESDestinationAddress: {S: SESDestinationAddress}, SESbounceSummary: {S: SESbounceSummary},
                     SESMessageType: {S: SESMessageType}, SESBounceType : {S: SESbounceType}, SESBounceSubType : {S: SESbounceSubType}}};

    ddb.putItem(itembounceParams, function(err, data) {
      if (err) { 
        context.fail(err);
      }
      else {
        //console.log(data);
        context.succeed();
      }
    });

  }
  else if (SESMessageType == 'Delivery') {
    var SESdeliverysmtpResponse = SESMessage.delivery.smtpResponse;
    var SESdeliveryreportingMTA = SESMessage.delivery.reportingMTA;
    if (SESdeliveryreportingMTA == null) SESdeliveryreportingMTA = "UNKNOWN";
    var itemdeliveryParams = {Item: {SESMessageId: {S: SESMessageId}, SnsPublishTime: {S: SnsPublishTime},
                        ExpiryTimestamp: {N: ExpiryTimestamp}, SESsmtpResponse: {S: SESdeliverysmtpResponse},
                        SESreportingMTA: {S: SESdeliveryreportingMTA},
                        SESDestinationAddress: {S: SESDestinationAddress }, SESMessageType: {S: SESMessageType}}};

    ddb.putItem(itemdeliveryParams, function(err, data) {
      if (err) { 
          context.fail(err);
      }
      else {
          //console.log(data);
          context.succeed();
      }
    });

  }
  else if (SESMessageType == 'Complaint') {
    var SESComplaintFeedbackType = SESMessage.complaint.complaintFeedbackType;
    var SESComplaintFeedbackId = SESMessage.complaint.feedbackId;
    var SESComplaintSummary = JSON.stringify(SESMessage.complaint);
    var itemcomplaintParams = {Item: {SESMessageId: {S: SESMessageId}, SnsPublishTime: {S: SnsPublishTime},
                         ExpiryTimestamp: {N: ExpiryTimestamp}, SESComplaintFeedbackType: {S: SESComplaintFeedbackType},
                         SESFeedbackId: {S: SESComplaintFeedbackId}, SESComplaintSummary: {S: SESComplaintSummary},
                         SESDestinationAddress: {S: SESDestinationAddress }, SESMessageType: {S: SESMessageType}}};
    ddb.putItem(itemcomplaintParams, function(err, data) {
      if (err) {
          context.fail(err);
      }
      else {
          //console.log(data);
          context.succeed();
      }

    });
  }

};