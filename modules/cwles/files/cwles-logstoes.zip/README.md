# cwles-logstoes

Parameterised duplication of default AWS Lambda function for shipping CloudWatch Logs to Elasticsearch

Used by [cwles](https://github.com/Zordrak/cwles)
