# logar-curator

Lambda function that curates indices in an Elasticsearch cluster

Used by [Logar](https://github.com/everydayhero/logar)

Forked and updated by Zordrak to curate AWS ES clusters
