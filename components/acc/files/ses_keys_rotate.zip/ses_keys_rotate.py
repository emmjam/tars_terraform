import boto3
from botocore.exceptions import ClientError
import sys
import hmac
import hashlib
import base64

iam_client = boto3.client('iam')
ssm_client = boto3.client("ssm")
#user_name_filter = "-ses-dev01-"
user_name_filter = "ses-ian"
msg = ""


def create_new_access_key(username):
    try:
        access_key_metadata = iam_client.create_access_key(UserName=username)
        new_access_key = access_key_metadata['AccessKey']['AccessKeyId']
        new_secret_key = access_key_metadata['AccessKey']['SecretAccessKey']
        iam_client.update_access_key(UserName=username, AccessKeyId=new_access_key, Status="Active")
        print("Key created: " + new_access_key)
    except ClientError as e:
        print("ERROR: Failed to create new access key")
        sys.exit(1)
    return(new_access_key,new_secret_key)


def sign(key, msg):
    return hmac.new(key, msg.encode('utf-8'), hashlib.sha256).digest()


def create_new_ses_key(secret_access_key):
    DATE = "11111111"
    SERVICE = "ses"
    MESSAGE = "SendRawEmail"
    TERMINAL = "aws4_request"
    VERSION = 0x04
    
    try: 
        region = 'eu-west-1'
        signature = sign(("AWS4" + secret_access_key).encode('utf-8'), DATE)
        signature = sign(signature, region)
        signature = sign(signature, SERVICE)
        signature = sign(signature, TERMINAL)
        signature = sign(signature, MESSAGE)
        signature_and_version = bytes([VERSION]) + signature
        smtp_password = base64.b64encode(signature_and_version)
    except ClientError as e:
        print("ERROR: Failed to create new encrypted SES key")
        sys.exit(1)
    return smtp_password.decode('utf-8')


def remove_old_access_key(access_key, username):
    try:
        iam_client.update_access_key(UserName=username, AccessKeyId=access_key, Status="Inactive")
        iam_client.delete_access_key(UserName=username, AccessKeyId=access_key)
        print("Key removed: " + access_key)
    except ClientError as e:
        print("ERROR: The access key with id %s cannot be found" % access_key)
        sys.exit(1)


def store_key(new_ses_key, username):
    try:
        paramname='SES-' + username
        ssm_client.put_parameter(
            Name=paramname,
            Description='SES key for user',
            Value=new_ses_key,
            Type='SecureString',
            Overwrite=True,
            Tier='Standard',
            DataType='text')
        txt=("Parameter Store updated: " + paramname )
        print(txt)
    except ClientError as e:
        print("ERROR: Failed to create Parameter Store entry")
        sys.exit(1)
    return txt


def lambda_handler(event, context):
    details = iam_client.list_users(MaxItems=300)
    users = details['Users']
    
    for user in users:
        
        if user['UserName'] != None :
            if user_name_filter in user['UserName'] : 
                username=user['UserName']
                print("Processing user : " + username)
    
                paginator = iam_client.get_paginator('list_access_keys')
                print(paginator)
                for x in paginator.paginate(UserName=username):
                    user_iam_details=x["AccessKeyMetadata"]
                for x in user_iam_details:
                    old_access_key = x["AccessKeyId"]
                    # Remove all old IAM access keys
                    remove_old_access_key(old_access_key, username)
                                
                # Create a new IAM access key
                new_access_key,new_secret_key=create_new_access_key(username=user['UserName']) 
                     
                # Create a new encrypted SES key from the new IAM Access Key
                new_ses_key=create_new_ses_key((new_secret_key))   # https://aws.amazon.com/premiumsupport/knowledge-center/ses-rotate-smtp-access-keys/
    
                # Store the new keys in the AWS Param Store
                msg = msg + store_key(new_ses_key, username) + "\n"
    
                print("\n")
    
        else:
            print("No users found")    
    
    print("Job done.")
  
    return {
        'statusCode': 200,
        'body': list_access_key(user=user,days_filter=0,status_filter='Active')
    }